haplo.GWAS<-function(Strfile,Manhattan,Genefile,Phefile,Chrom,max.merge,num.comp,p.adjust.method,threshold){

  print("Reading genotype and phenotype data...")
  gene.total<-read.table(file=Genefile, header = T,check.names = FALSE)
  max.hap<-apply(gene.total[,-(1:4)],1,max)
  index<-which(max.hap==1)
  if(length(index)!=0){
    gene<-gene.total[-index,]
  }else{
    gene<-gene.total
  }

  phe<-read.csv(file=Phefile,row.names = 1)
  gene0<-as.matrix(gene.total[,-(1:4)])
  ind.name.gene<-colnames(gene0)
  ind.name.phe<-rownames(phe)

  ind.check<-ind.name.gene==ind.name.phe
  if(length(which(ind.check==FALSE))!=0) {
    stop("The names of observations are not consistant in phenotypic and genomic data! Require the same order and number of individuals in Genefile and Phefile.")
  }


  if (Chrom=="all"){
    gene_match0<-gene
    gene_match<-as.matrix(gene_match0[,-c(1:4)])
  }else {
    chr<-which(gene$Chr==Chrom)
    gene_match0<-gene[chr,]
    gene_match<-as.matrix(gene_match0[,-c(1:4)])

  }

  merge<-function(a){
    freq<-table(a)
    index<-which(freq<max.merge)
    name<-names(freq[index])
    check<-as.numeric(name)
    pos<-NULL
    for( p in 1:length(check)){
      pos0<-which(a==check[p])
      pos<-c(pos,pos0)
    }
    a[pos]<-0
    return(a)
  }

  delete<-function(a){
    b<-length(unique(a))
    return(b)
  }


  if( is.null(max.merge))  {
    z<-gene_match
  }  else {
    haplo.merge<-apply(gene_match,1,merge)

    haplo.merge2<-apply(haplo.merge,2,delete)

    index.delete<-which(haplo.merge2==1)

    if (length(index.delete)!=0){
      z<-t(haplo.merge[,-index.delete])
      marker.name<-gene_match0[-index.delete,1:4]
    }else {
      z<-t(haplo.merge)
      marker.name<-gene_match0[,1:4]
    }

  }

  print("Calculating kinship matrix...")
  gene1<-as.matrix(z)
  gene2<-matrix(as.numeric(gene1),nrow=nrow(gene1))
  k1<-dim(gene1)[2]
  k2<-dim(gene1)[1]
  kinship0<-matrix(0,k1,k1)

  for(i in 1:k2){
    dummy<-class.ind(gene1[i,])
    kin<-crossprod(t(dummy))
    kinship0<-kinship0+kin
  }


  kinship<-kinship0/mean(diag(kinship0))

  if (!is.null(Strfile)){

    str<- read.csv(file=Strfile,row.names = 1)
  }else if(is.null(num.comp)){
    str<-matrix(1,nrow(phe),1)
  }else {
    pca<-principal(kinship,num.comp)
    str<-as.matrix(pca$Structure)
  }


  haplo.GWAS.result<-list()
  trait.name<-names(phe)
  chr.name<-Chrom


  for (i in 1:ncol(phe)){
    y<-as.matrix(phe[,i])
    mean.y<-mean(y,na.rm = TRUE)
    y[is.na(y)]<-mean.y
    n<-length(y)
    print(paste("Trait",i, "haplotype GWAS is scanning..."))

    m<-dim(z)[1]

    kk<-as.matrix(kinship)
    x<-as.matrix(str)
    qq<-eigen(kk,symmetric=T)
    delta<-qq[[1]]
    uu<-qq[[2]]
    yu<-t(uu)%*%y
    xu<-t(uu)%*%x
    gen<-gene[,-(1:4)]
    q<-ncol(x)
    n<-length(y)

    mixed1<-function(x,y,kk,method="ML",Eigen=FALSE){

      loglike<-function(theta){
        lambda<-exp(theta)
        logdt<-sum(log(lambda*delta+1))
        h<-1/(lambda*delta+1)
        yy<-sum(yu*h*yu)
        yx<-matrix(0,s,1)
        xx<-matrix(0,s,s)
        for(i in 1:s){
          yx[i]<-sum(yu*h*xu[,i])
          for(j in 1:s){
            xx[i,j]<-sum(xu[,i]*h*xu[,j])
          }
        }
        xx
        if(method=="REML"){
          loglike<- -0.5*logdt-0.5*(n-s)*log(yy-t(yx)%*%solve(xx+diag(1e-8,s))%*%yx)-0.5*log(det(xx+diag(1e-8,s)))
        } else {
          loglike<- -0.5*logdt-0.5*n*log(yy-t(yx)%*%solve(xx+diag(1e-8,s))%*%yx)
        }
        return(-loglike)
      }


      fixed<-function(lambda){
        h<-1/(lambda*delta+1)
        yy<-sum(yu*h*yu)
        yx<-matrix(0,s,1)
        xx<-matrix(0,s,s)
        for(i in 1:s){
          yx[i]<-sum(yu*h*xu[,i])
          for(j in 1:s){
            xx[i,j]<-sum(xu[,i]*h*xu[,j])
          }
        }
        beta<-solve(xx+diag(1e-8,s),yx)
        if(method=="REML"){
          sigma2<-(yy-t(yx)%*%solve(xx+diag(1e-8,s))%*%yx)/(n-s)
        } else {
          sigma2<-(yy-t(yx)%*%solve(xx+diag(1e-8,s))%*%yx)/n
        }
        var<-diag(solve(xx+diag(1e-8,s))*drop(sigma2))
        stderr<-sqrt(var)
        return(c(beta,stderr,sigma2))
      }

      n<-length(y)

      if(is.matrix(kk)){
        qq<-eigen(kk,symmetric=TRUE)
      } else {
        if(is.data.frame(kk)){
          qq<-eigen(as.matrix(kk),symmetric=TRUE)
        } else {
          qq<-kk
        }
      }
      delta<-qq[[1]]
      uu<-qq[[2]]
      s<-ncol(x)
      yu<-t(uu)%*%y
      xu<-t(uu)%*%x
      theta<-0
      parm<-optim(par=theta,fn=loglike,NULL,hessian = TRUE, method="L-BFGS-B",lower=-10,upper=10)
      lambda<-exp(parm$par)
      conv<-parm$convergence
      fn1<-parm$value
      fn0<-loglike(-Inf)
      lrt<-2*(fn0-fn1)
      hess<-parm$hessian
      parmfix<-fixed(lambda)
      beta<-parmfix[1:s]
      stderr<-parmfix[(s+1):(2*s)]
      ve<-parmfix[2*s+1]
      lod<-lrt/4.61
      p_value<-1-pchisq(lrt,1)
      va<-lambda*ve
      h2<-va/(va+ve)
      par<-data.frame(method,beta,stderr,va,ve,lambda,h2,conv,fn1,fn0,lrt,lod,p_value)
      if(Eigen){
        return(list(par,qq))
      } else {
        return(list(par))
      }
    }
    mixed2FixedLambda<-function(x,z,y,kk,lambda=lambda,method="ML",Eigen=F){

      if(is.matrix(kk)|is.data.frame(kk)){
        qq<-eigen(as.matrix(kk),symmetric=T)
        delta<-qq[[1]]
        uu<-qq[[2]]
        yu<-t(uu)%*%y
        xu<-t(uu)%*%x
        zu<-t(uu)%*%z
      } else {
        xu<-x
        zu<-z
        yu<-y
      }
      q<-ncol(x)
      r<-ncol(z)
      n<-length(y)

      loglike<-function(theta){
        lambda<-lambda
        logdt1<-sum(log(lambda*delta+1))
        h<-1/(lambda*delta+1)
        xi<-exp(theta)
        yy<-sum(yu*h*yu)
        yx<-matrix(0,q,1)
        xx<-matrix(0,q,q)
        zx<-matrix(0,q,r)
        zy<-matrix(0,r,1)
        zz<-matrix(0,r,r)
        for(i in 1:q){
          yx[i]<-sum(yu*h*xu[,i])
          for(j in 1:q){
            xx[i,j]<-sum(xu[,i]*h*xu[,j])
          }
          for(j in 1:r){
            zx[i,j]<-sum(xu[,i]*h*zu[,j])
          }
        }
        for(i in 1:r){
          zy[i]<-sum(yu*h*zu[,i])
          for(j in 1:r){
            zz[i,j]<-sum(zu[,i]*h*zu[,j])
          }
        }
        tmp<-solve(xi*zz+diag(r))
        yHy<-yy-xi*t(zy)%*%tmp%*%zy
        yHx<-yx-xi*zx%*%tmp%*%zy
        xHx<-xx-xi*zx%*%tmp%*%t(zx)
        logdt2<-log(det(xi*zz+diag(r)))
        if(method=="REML"){
          loglike<- -0.5*logdt1-0.5*logdt2-0.5*(n-q)*log(yHy-t(yHx)%*%solve(xHx)%*%yHx)-0.5*log(det(xHx))
        } else {
          loglike<- -0.5*logdt1-0.5*logdt2-0.5*n*log(yHy-t(yHx)%*%solve(xHx)%*%yHx)
        }
        if (!is.finite(loglike)) loglike<--1e+10
        return(-loglike)
      }

      fixed<-function(lambda,xi){
        h<-1/(lambda*delta+1)
        yy<-sum(yu*h*yu)
        yx<-matrix(0,q,1)
        xx<-matrix(0,q,q)
        zx<-matrix(0,q,r)
        zy<-matrix(0,r,1)
        zz<-matrix(0,r,r)
        for(i in 1:q){
          yx[i]<-sum(yu*h*xu[,i])
          for(j in 1:q){
            xx[i,j]<-sum(xu[,i]*h*xu[,j])
          }
          for(j in 1:r){
            zx[i,j]<-sum(xu[,i]*h*zu[,j])
          }
        }
        for(i in 1:r){
          zy[i]<-sum(yu*h*zu[,i])
          for(j in 1:r){
            zz[i,j]<-sum(zu[,i]*h*zu[,j])
          }
        }
        tmp<-solve(xi*zz+diag(r))
        yHy<-yy-xi*t(zy)%*%tmp%*%zy
        yHx<-yx-xi*zx%*%tmp%*%zy
        xHx<-xx-xi*zx%*%tmp%*%t(zx)
        zHy<-zy-xi*zz%*%tmp%*%zy
        zHx<-zx-xi*zx%*%tmp%*%zz
        zHz<-zz-xi*zz%*%tmp%*%zz
        if(method=="REML"){ df<-n-q } else { df<-n }
        sigma2<-drop(yHy-t(yHx)%*%solve(xHx)%*%yHx)/df
        blue<-drop(solve(xHx,yHx))
        blue.err<-sqrt(abs(diag(solve(xHx)*sigma2)))
        blup<-drop(xi*zHy-xi*t(zHx)%*%solve(xHx)%*%yHx)
        blup.err<-sqrt(abs(diag(xi*diag(r)-xi^2*zHz)*sigma2))
        fixed<-data.frame(blue,blue.err)
        random<-data.frame(blup,blup.err)
        sigma2<-data.frame(sigma2)
        return(list(sigma2,fixed,random))
      }
      theta<-0.5
      reml<-optim(par=theta,fn=loglike,method="L-BFGS-B",lower=-10,upper=10)
      lambda<-lambda
      fn<-reml$value
      xi<-exp(reml$par)
      parm<-fixed(lambda,xi)
      if(Eigen){
        value<-list(lambda,xi,parm,fn,qq)
      } else {
        value<-list(lambda,xi,parm,fn)
      }
      return(value)
    }

    fixed<-mixed1(x=x,y=y,kk=qq,method="ML",Eigen=F)
    l0<-fixed[[1]]$fn1[1]
    lambda<-fixed[[1]]$lambda[1]

    core<-detectCores() #operate multiple strings
    if(core<=2){
      cl.core<-1
    }else if (core>2){
      if(core>12){
        cl.core<-12
      } else cl.core<-core-1
    }
    cl<-makeCluster(cl.core)
    registerDoParallel(cl)
    parr<-  foreach(k=1:m, .multicombine=TRUE,.combine="rbind") %dopar% {

      #library(nnet)
      #uu<-qq[[2]]
      delta<-qq[[1]]
      zk<-class.ind(z[k,])
      print(k)
      zu<-t(uu)%*%zk
      r<-ncol(zu)
      random<-mixed2FixedLambda(x=xu,z=zu,y=yu,kk=qq,lambda=lambda,method="ML",Eigen=F)
      l1<-random[[4]]
      lrt<-2*(l0-l1)
      lrt.test<-pchisq(lrt,df=1,lower.tail=FALSE)
      lambda<-random[[1]]
      xi<-random[[2]]
      sigma2<-random[[3]][[1]]
      va<-lambda*sigma2
      vg<-xi*sigma2
      names(va)<-"va"
      names(vg)<-"vg"
      blue<-random[[3]][[2]]$blue
      blue.err<-random[[3]][[2]]$blue.err
      blup<-random[[3]][[3]]$blup
      blup.err<-random[[3]][[3]]$blup.err
      w2<-(blup/blup.err)^2
      w2<-sum((blup/blup.err)^2)
      p2<-1-pchisq(w2,r-1)
      lp2<--log10(p2)
      w3<-max(lrt,0)
      p3<-1-pchisq(w3,1)
      lg10<--log10(lrt.test)
      df<-max(1-(blup.err)^2/vg,0)
      par<-data.frame(r,va,vg,sigma2,lrt,lrt.test)[1,]
    }
    stopCluster(cl)

    p.value<-parr$lrt.test
    p.value.adj<-p.adjust(p.value,method=p.adjust.method)
    result.total<-cbind(marker.name,parr,p.value.adj)
    result.sig<-subset(result.total,p.value.adj<threshold)


    res<-list(result.total,result.sig)
    names(res)<-c("haplo.total","haplo.sig")

    haplo.GWAS.result[[i]]<-res
    write.csv(res$haplo.total,file=paste(i,"_",trait.name[i],"_",chr.name,"_total.result.csv",sep=""),row.names = FALSE)
    write.csv(res$haplo.sig,file=paste(i,"_",trait.name[i],"_",chr.name,"_sig.result.csv",sep=""),row.names = FALSE)

    if (Manhattan==TRUE){
      png(filename=paste(i,"_",trait.name[i],"_",chr.name,"_Manhattan_and_QQ.png",sep=""),width=1200,height = 300)
      print("Drawing the Manhattan and QQ plot...")
      par(mar=c(5,6,4,2)+0.1,mfrow=c(2,4))#5642=low,left,up,right.
      #layout(matrix(c(rep(1,3),2,rep(3,3),4),ncol = 4,byrow = T))
      layout(matrix(c(rep(1,3),2),ncol = 4,byrow = T))
      SUGGEST=1/nrow(res$haplo.total)
      SIG=0.05/nrow(res$haplo.total)
      par(pty="m")
      pic.data0<-res$haplo.total[,c(1:3,10)]
      names(pic.data0)<-c("CHR","SNP","BP","P")
      pic.data0$CHR<-as.numeric(gsub("chr","",pic.data0$CHR))
      num.chr<-length(unique(pic.data0$CHR))

      chr0<-NULL
      for ( c in 1:num.chr){
        chr<-paste("Chr",c,sep="")
        chr0<-c(chr0,chr)

      }

      qqman::manhattan(pic.data0,chr="CHR",bp="BP",p="P",snp="SNP",col=c("blue4", "orange3"),chrlabs=chr0,suggestiveline=-log10(SUGGEST),genomewideline=-log10(SIG),logp=TRUE,main=trait.name[i],cex.axis=1.1,cex.lab=1.8,cex.main=2)

      par(pty="s")

      qqman::qq(pic.data0$P,main=trait.name[i],col="blue4",cex.axis=1.2,cex.lab=1.8,cex.main=2)

      dev.off()
    }

  }

  return(haplo.GWAS.result)
}

