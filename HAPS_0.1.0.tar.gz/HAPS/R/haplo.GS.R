haplo.GS<-function(Strfile,Genefile1,Phefile1,Genefile2,max.merge,num.comp){

  print("Reading genotype and phenotype data...")
  gene.total1<-read.table(file=Genefile1, header = T,check.names = FALSE)
  gene.total2<-read.table(file=Genefile2, header = T,check.names = FALSE)
  gene.total<-cbind(gene.total1,gene.total2[,-c(1:4)])
  max.hap<-apply(gene.total[,-(1:4)],1,max)
  index<-which(max.hap==1)
  if(length(index)!=0){
    gene<-gene.total[-index,]
  }else{
    gene<-gene.total
  }

  phe<-read.csv(file=Phefile1,row.names = 1)

  print("Calculating kinship matrix...")
  gene1<-as.matrix(gene[,-c(1:4)])
  gene2<-matrix(as.numeric(gene1),nrow=nrow(gene1))
  k1<-dim(gene2)[2]
  k2<-dim(gene2)[1]
  kinship0<-matrix(0,k1,k1)

  for(i in 1:k2){
    dummy<-class.ind(gene1[i,])
    kin<-crossprod(t(dummy))
    kinship0<-kinship0+kin
  }

  kinship<-kinship0/mean(diag(kinship0))


  if (!is.null(Strfile)){

    str<- read.csv(file=Strfile,row.names = 1)
  }else if(is.null(num.comp)){
    str<-matrix(1,nrow(phe),1)
  }else {
    pca<-principal(kinship,num.comp)
    str<-as.matrix(pca$Structure)
  }
  print("Predicting the phenotype...")
  mixed=function(x,y,kk,method="REML",Eigen=FALSE){

    loglike<-function(theta){
      lambda<-exp(theta)
      logdt<-sum(log(lambda*delta+1))
      h<-1/(lambda*delta+1)
      yy<-sum(yu*h*yu)
      yx<-matrix(0,s,1)
      xx<-matrix(0,s,s)
      for(i in 1:s){
        yx[i]<-sum(yu*h*xu[,i])
        for(j in 1:s){
          xx[i,j]<-sum(xu[,i]*h*xu[,j])
        }
      }
      xx
      if(method=="REML"){
        loglike<- -0.5*logdt-0.5*(n-s)*log(yy-t(yx)%*%solve(xx)%*%yx)-0.5*log(det(xx))
      } else {
        loglike<- -0.5*logdt-0.5*n*log(yy-t(yx)%*%solve(xx)%*%yx)
      }
      return(-loglike)
    }


    fixed<-function(lambda){
      h<-1/(lambda*delta+1)
      yy<-sum(yu*h*yu)
      yx<-matrix(0,s,1)
      xx<-matrix(0,s,s)
      for(i in 1:s){
        yx[i]<-sum(yu*h*xu[,i])
        for(j in 1:s){
          xx[i,j]<-sum(xu[,i]*h*xu[,j])
        }
      }
      beta<-solve(xx,yx)
      if(method=="REML"){
        sigma2<-(yy-t(yx)%*%solve(xx)%*%yx)/(n-s)
      } else {
        sigma2<-(yy-t(yx)%*%solve(xx)%*%yx)/n
      }
      var<-diag(solve(xx)*drop(sigma2))
      stderr<-sqrt(var)
      return(c(beta,stderr,sigma2))
    }

    #n<-length(y)
    n=length(y)
    qq<-eigen(kk,symmetric=TRUE)
    delta<-qq[[1]]
    uu<-qq[[2]]
    s<-ncol(x)
    yu<-t(uu)%*%y
    xu<-t(uu)%*%x
    theta<-0
    #parm<-optim(par=theta,fn=loglike,NULL,hessian = TRUE, method="L-BFGS-B",lower=-10,upper=10)
    parm<-optim(par=theta,fn=loglike,NULL,hessian = TRUE, method="Brent",lower=-100,upper=100)
    lambda<-exp(parm$par)
    conv<-parm$convergence
    fn1<-parm$value
    fn0<-loglike(-Inf)
    lrt<-2*(fn0-fn1)
    hess<-parm$hessian
    parmfix<-fixed(lambda)
    beta<-parmfix[1:s]
    stderr<-parmfix[(s+1):(2*s)]
    ve<-parmfix[2*s+1]
    lod<-lrt/4.61
    p_value<-1-pchisq(lrt,1)
    va<-lambda*ve
    h2<-va/(va+ve)
    par<-data.frame(method,beta,stderr,va,ve,lambda,h2,conv,fn1,fn0,lrt,lod,p_value)
    if(Eigen){
      return(list(par,qq))
    } else {
      return(list(par))
    }
  }
  x<-str
  y<-as.matrix(phe)
  kk<-kinship
  i1<-c(1:(ncol(gene.total1)-4))
  i2<-c((ncol(gene.total1)-3):ncol(gene1))
  x1<-x[i1,]
  k11<-kk[i1,i1]
  ypred<-NULL
  for(i in 1:ncol(phe)){
    y1<-y[,i]
    parm<-mixed(x=x1,y=y1,kk=k11,method="REML",Eigen =TRUE)
    qq<-parm[[2]]
    delta<-qq[[1]]
    u<-qq[[2]]
    beta<-as.matrix(parm[[1]]$beta,ncol(x),1)
    va<-parm[[1]]$va[1]
    ve<-parm[[1]]$ve[1]
    x2<-x[i2,]
    k21<-kk[i2,i1]
    h<-1/(delta*va+ve)
    y3<-x2%*%beta+va*k21%*%u%*%diag(h)%*%t(u)%*%(y1-x1%*%beta)
    ypred<-cbind(ypred,y3)
  }
  colnames(ypred)<-names(phe)
  Line<-row.names(ypred)
  ypred2<-data.frame(Line,ypred)
  write.csv(ypred2,file="predict_phe.csv",row.names = FALSE)
  print("Done")
}
