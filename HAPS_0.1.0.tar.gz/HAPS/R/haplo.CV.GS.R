haplo.CV.GS<-function(Strfile,Genefile,Phefile,Chrom,max.merge,num.comp,nfold){

  print("Reading genotype and phenotype data...")
  gene.total<-read.table(file=Genefile, header = T,check.names = FALSE)
  max.hap<-apply(gene.total[,-(1:4)],1,max)
  index<-which(max.hap==1)
  if(length(index)!=0){
    gene<-gene.total[-index,]
  }else{
    gene<-gene.total
  }

  phe<-read.csv(file=Phefile,row.names = 1)
  gene0<-as.matrix(gene.total[,-(1:4)])
  ind.name.gene<-colnames(gene0)
  ind.name.phe<-rownames(phe)

  ind.check<-ind.name.gene==ind.name.phe
  if(length(which(ind.check==FALSE))!=0) {
    stop("The names of observations are not consistant in phenotypic and genomic data! Require the same order and number of individuals in Genefile and Phefile.")
  }

  if (Chrom=="all"){
    gene_match0<-gene
    gene_match<-as.matrix(gene_match0[,-c(1:4)])
  }else {
    chr<-which(gene$Chr==Chrom)
    gene_match0<-gene[chr,]
    gene_match<-as.matrix(gene_match0[,-c(1:4)])

  }

  merge<-function(a){
    freq<-table(a)
    index<-which(freq<max.merge)
    name<-names(freq[index])
    check<-as.numeric(name)
    pos<-NULL
    for( p in 1:length(check)){
      pos0<-which(a==check[p])
      pos<-c(pos,pos0)
    }
    a[pos]<-0
    return(a)
  }

  delete<-function(a){
    b<-length(unique(a))
    return(b)
  }


  if( is.null(max.merge))  {
    z<-gene_match
  }  else {
    haplo.merge<-apply(gene_match,1,merge)

    haplo.merge2<-apply(haplo.merge,2,delete)

    index.delete<-which(haplo.merge2==1)

    if (length(index.delete)!=0){
      z<-t(haplo.merge[,-index.delete])
      marker.name<-gene_match0[-index.delete,1:4]
    }else {
      z<-t(haplo.merge)
    }

  }

  print("Calculating kinship matrix...")
  gene1<-as.matrix(z)
  gene2<-matrix(as.numeric(gene1),nrow=nrow(gene1))
  k1<-dim(gene1)[2]
  k2<-dim(gene1)[1]
  kinship0<-matrix(0,k1,k1)

  for(i in 1:k2){
    dummy<-class.ind(gene1[i,])
    kin<-crossprod(t(dummy))
    kinship0<-kinship0+kin
  }


  kinship<-kinship0/mean(diag(kinship0))

  if (!is.null(Strfile)){

    str<- read.csv(file=Strfile,row.names = 1)
  }else if(is.null(num.comp)){
    str<-matrix(1,nrow(phe),1)
  }else {
    pca<-principal(kinship,num.comp)
    str<-as.matrix(pca$Structure)
  }

  mixed=function(x,y,kk,method="REML",Eigen=FALSE){

    loglike<-function(theta){
      lambda<-exp(theta)
      logdt<-sum(log(lambda*delta+1))
      h<-1/(lambda*delta+1)
      yy<-sum(yu*h*yu)
      yx<-matrix(0,s,1)
      xx<-matrix(0,s,s)
      for(i in 1:s){
        yx[i]<-sum(yu*h*xu[,i])
        for(j in 1:s){
          xx[i,j]<-sum(xu[,i]*h*xu[,j])
        }
      }
      xx
      if(method=="REML"){
        loglike<- -0.5*logdt-0.5*(n-s)*log(yy-t(yx)%*%solve(xx)%*%yx)-0.5*log(det(xx))
      } else {
        loglike<- -0.5*logdt-0.5*n*log(yy-t(yx)%*%solve(xx)%*%yx)
      }
      return(-loglike)
    }


    fixed<-function(lambda){
      h<-1/(lambda*delta+1)
      yy<-sum(yu*h*yu)
      yx<-matrix(0,s,1)
      xx<-matrix(0,s,s)
      for(i in 1:s){
        yx[i]<-sum(yu*h*xu[,i])
        for(j in 1:s){
          xx[i,j]<-sum(xu[,i]*h*xu[,j])
        }
      }
      beta<-solve(xx,yx)
      if(method=="REML"){
        sigma2<-(yy-t(yx)%*%solve(xx)%*%yx)/(n-s)
      } else {
        sigma2<-(yy-t(yx)%*%solve(xx)%*%yx)/n
      }
      var<-diag(solve(xx)*drop(sigma2))
      stderr<-sqrt(var)
      return(c(beta,stderr,sigma2))
    }

    #n<-length(y)
    n=length(y)
    qq<-eigen(kk,symmetric=TRUE)
    delta<-qq[[1]]
    uu<-qq[[2]]
    s<-ncol(x)
    yu<-t(uu)%*%y
    xu<-t(uu)%*%x
    theta<-0
    #parm<-optim(par=theta,fn=loglike,NULL,hessian = TRUE, method="L-BFGS-B",lower=-10,upper=10)
    parm<-optim(par=theta,fn=loglike,NULL,hessian = TRUE, method="Brent",lower=-100,upper=100)
    lambda<-exp(parm$par)
    conv<-parm$convergence
    fn1<-parm$value
    fn0<-loglike(-Inf)
    lrt<-2*(fn0-fn1)
    hess<-parm$hessian
    parmfix<-fixed(lambda)
    beta<-parmfix[1:s]
    stderr<-parmfix[(s+1):(2*s)]
    ve<-parmfix[2*s+1]
    lod<-lrt/4.61
    p_value<-1-pchisq(lrt,1)
    va<-lambda*ve
    h2<-va/(va+ve)
    par<-data.frame(method,beta,stderr,va,ve,lambda,h2,conv,fn1,fn0,lrt,lod,p_value)
    if(Eigen){
      return(list(par,qq))
    } else {
      return(list(par))
    }
  }


  cv.mixed<-function(x,y,kk,method="REML",nfold=10,foldid=foldid){

    yobs<-NULL
    yhat<-NULL
    fold<-NULL
    id<-NULL
    for(k in 1:nfold){
      i1<-which(foldid!=k)
      i2<-which(foldid==k)
      x1<-x[i1,,drop=F]
      y1<-y[i1,,drop=F]

      k11<-kk[i1,i1]
      parm<-mixed(x=x1,y=y1,kk=k11,method="REML",Eigen =TRUE)
      qq<-parm[[2]]
      delta<-qq[[1]]
      u<-qq[[2]]
      beta<-as.matrix(parm[[1]]$beta,ncol(x),1)
      va<-parm[[1]]$va[1]
      ve<-parm[[1]]$ve[1]
      x2<-x[i2,,drop=F]
      y2<-y[i2,,drop=F]
      k21<-kk[i2,i1]
      h<-1/(delta*va+ve)
      y3<-x2%*%beta+va*k21%*%u%*%diag(h)%*%t(u)%*%(y1-x1%*%beta)
      #y3<-x2%*%beta+va*k21%*%solve(k11*va+diag(length(y1))*ve)%*%(y1-x1%*%beta)
      fold<-c(fold,rep(k,length(y2)))
      yobs<-c(yobs,y2)
      yhat<-c(yhat,y3)
      id<-c(id,i2)
    }
    pred<-data.frame(fold,id,yobs,yhat)
    cv.r2<-cor(pred$yobs,pred$yhat)^2
    return(list(data.frame(r2=cv.r2),pred))
  }


  r2<-NULL
  num<-NULL

  y0<-as.matrix(phe)
  n0<-nrow(y0)
  x<-as.matrix(str)
  kk<-kinship
  nfold=nfold
  foldid<-sample(rep(1:nfold,ceiling(n0/nfold))[1:n0])
  trait<-names(phe)
  for(i in 1:ncol(y0)){
    pred<-NULL
    y<-as.matrix(y0[,i])
    blup<-cv.mixed(x=x,y=y,kk=kk,foldid=foldid)
    r2<-rbind(r2,blup[[1]])
    pred<-rbind(pred,blup[[2]])
    write.csv(pred,file=paste(trait[i],"_predction phe.csv",sep=""),row.names = FALSE)
  }
  r2.final<-cbind(trait,r2)
  write.csv(r2.final,file="prediction accuracy.csv",row.names = FALSE)
  print("Done")
}
